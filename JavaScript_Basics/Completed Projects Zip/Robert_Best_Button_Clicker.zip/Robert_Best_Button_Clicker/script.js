

function logOut(element) {
    element.innerText = "Log Out";
}

function hide(element) {
    element.remove();
}