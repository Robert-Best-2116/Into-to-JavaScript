
var count = 9;
var countElement = document.querySelector(".count");

console.log(countElement)

function add1() {   
    count++;
    countElement.innerText = count + " Like(s)";
    console.log(count);
}


var add = 12;
var countElement2 = document.querySelector(".add");

console.log (countElement2);

function addd1(){
    add++
    countElement2.innerText = add + " Like(s)";
    console.log(add);
}

var num = 9;
var countElement3 =document.querySelector(".number");

console.log (countElement3);

function adddd1(){
    num++
    countElement3.innerText = num + " Like(s)";
    console.log(add);
}